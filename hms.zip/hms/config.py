MYSQL_CONFIG = {
    'host': 'localhost',          # Or '127.0.0.1'
    'port': 3306,                 # Specify the port explicitly
    'user': 'root', # Replace with your actual MySQL username
    'password': 'Bv@04102004', # Replace with your actual MySQL password
    'database': 'hospital_management'  # Ensure this database exists
}
