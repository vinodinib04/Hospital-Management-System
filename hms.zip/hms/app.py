# app.py
from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from config import MYSQL_CONFIG
from mysql.connector import Error, IntegrityError

app = Flask(__name__)
app.secret_key = 'your_unique_secret_key'

# Database Connection
def get_db_connection():
     conn = mysql.connector.connect(
        #host=MYSQL_CONFIG['host'],
        #port=MYSQL_CONFIG['port'],          # Include the port here
        #user=MYSQL_CONFIG['user'],
        #password=MYSQL_CONFIG['password'],
        #database=MYSQL_CONFIG['database']
        host='localhost',
        port='3306',
        user='root',
        password='root',
        database='hospital_management'
    )
     return conn

@app.route('/')
def index():
    return render_template('index.html')

# Patients Routes
@app.route('/patients')
def patients():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Patients')
    patients = cursor.fetchall()
    conn.close()
    return render_template('patients.html', patients=patients)

@app.route('/patients/add', methods=('GET', 'POST'))
def add_patient():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        gender = request.form['gender']
        contact = request.form['contact']
        address = request.form['address']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO Patients (name, age, gender, contact_number, address, admitted_date) VALUES (%s, %s, %s, %s, %s, NOW())',
                       (name, age, gender, contact, address))
        conn.commit()
        conn.close()
        return redirect(url_for('patients'))
    return render_template('add_patient.html')

# Doctors Routes
@app.route('/doctors')
def doctors():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Doctors')
    doctors = cursor.fetchall()
    conn.close()
    return render_template('doctors.html', doctors=doctors)

@app.route('/doctors/add', methods=('GET', 'POST'))
def add_doctor():
    if request.method == 'POST':
        name = request.form['name']
        specialty = request.form['specialty']
        contact = request.form['contact']
        email = request.form['email']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO Doctors (name, specialty, contact_number, email) VALUES (%s, %s, %s, %s)',
                       (name, specialty, contact, email))
        conn.commit()
        conn.close()
        return redirect(url_for('doctors'))
    return render_template('add_doctor.html')

# Appointments Routes
@app.route('/appointments')
def appointments():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Appointments')
    appointments = cursor.fetchall()
    conn.close()
    return render_template('appointments.html', appointments=appointments)

@app.route('/appointments/add', methods=('GET', 'POST'))
def add_appointment():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        doctor_id = request.form['doctor_id']
        appointment_date = request.form['appointment_date']
        status = request.form['status']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO Appointments (patient_id, doctor_id, appointment_date, status) VALUES (%s, %s, %s, %s)',
                           (patient_id, doctor_id, appointment_date, status))
            conn.commit()
            flash('Appointment added successfully!', 'success')
        except IntegrityError:
            flash('Error: Cannot add appointment. Please ensure the patient ID and doctor ID exist.', 'danger')
        except Error as e:
            flash(f'Error: {e}', 'danger')
        finally:
            cursor.close()
            conn.close()
        
        return redirect(url_for('appointments'))
    
    return render_template('add_appointment.html')

# Billing Routes
@app.route('/billing')
def billing():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Billing')
    billing_records = cursor.fetchall()
    conn.close()
    return render_template('billing.html', billing_records=billing_records)

@app.route('/billing/add', methods=('GET', 'POST'))
def add_billing():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        appointment_id = request.form['appointment_id']
        amount = request.form['amount']
        status = request.form['status']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO Billing (patient_id, appointment_id, amount, status) VALUES (%s, %s, %s, %s)',
                           (patient_id, appointment_id, amount, status))
            conn.commit()
            flash('Billing record added successfully!', 'success')
        except IntegrityError:
            flash('Error: Cannot add billing record. Please ensure the appointment ID exists.', 'danger')
        except Error as e:
            flash(f'Error: {e}', 'danger')
        finally:
            cursor.close()
            conn.close()
        
        return redirect(url_for('billing'))
    
    return render_template('add_billing.html')


if __name__ == '__main__':
    app.run(debug=True)
